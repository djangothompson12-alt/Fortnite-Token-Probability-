# Loot or Love?

A Monte Carlo comparison of finding Fortnite's Pirate Shop Access Token (1 in 137,500 chests) and getting a girlfriend.

**Paper:** [`loot-or-love.pdf`](loot-or-love.pdf)

| | |
|---|---|
| Odds per chest (token) | 1 in 137,500 |
| Odds per new person met in person | about 1 in 23,500 |
| Odds per cold DM | about 1 in 7,300 |
| Odds per right swipe | about 1 in 97,600 |
| Median solo hours to find the token | about 3,240 |
| Survival time that maximises chests per hour (closed form, Lambert W) | 5 min 49 s |
| Crossover across 400 prior draws (90% interval) | 15 to 46 h/week |
| Share of Fortnite time spent outside a match, after 800 matches (tired) | 54% |
| Weekly hours at which the token beats a girlfriend before 5 Dec 2026 | 19 on average, 11 for the bottom 20% by looks, 32 for the top 20% |

## Reproduce

```bash
pip install -r requirements.txt
python run_all.py          # writes results.json and figures/ (about 2-3 minutes)
python extras.py           # Lambert-W optimum check + Monte Carlo convergence
python psa.py 400          # uncertainty: 400 prior draws, full recalibration each (~8 min on 4 cores)
python psa_report.py       # intervals + Sobol indices
python social_figs.py      # 9:16 images in social/
cd paper && pdflatex paper.tex && pdflatex paper.tex
```

## What's in here

- `lootorlove/params.py` lists every parameter. Each one is marked **[S]** (sourced, with the citation) or **[A]** (an assumption that is tested in the sensitivity analysis).
- `lootorlove/token.py` is a per-player simulation of token hunting. It covers game mode, region, skill-based matchmaking, queue times that grow with skill, fatigue within a session and Treasure Hours.
- `lootorlove/love.py` holds the girlfriend equation. It has three channels (in person, dating apps and cold DMs) plus looks, local population density and time displaced by gaming. It's calibrated to Pew (63% of young men are single) and HCMST (39% of couples meet online).
- `run_all.py` produces every number and figure in the paper.

## Caveats

This is a joke paper with real maths. The drop rate is Epic's own published figure. The relationship side uses Pew, ATUS and HCMST data. Chests per match and some of the social parameters are assumptions, and the paper says which ones and how much they matter.
